#!/usr/bin/python
#
# tcpc1.py
#
from socket import socket, AF_INET, SOCK_STREAM
srvaddr = ('127.0.0.1', 11111)
s = socket(AF_INET, SOCK_STREAM)
s.connect(srvaddr)
while 1:
    data = input("Send: ")
    s.send(bytes(data ,'utf-8'))
    data = s.recv(1024)
    print(data)
    if data == b'#':
        break
s.close()

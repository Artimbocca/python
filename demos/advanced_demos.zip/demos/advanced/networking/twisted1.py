from twisted.internet import protocol, reactor, endpoints


# class Echo(protocol.Protocol):
#     def dataReceived(self, data):
#         self.transport.write(data)

class QOTD(protocol.Protocol):

    def connectionMade(self):
        self.transport.write(bytes("An apple a day keeps the doctor away\r\n", "utf-8"))
        self.transport.loseConnection()

class EchoFactory(protocol.Factory):
    def buildProtocol(self, addr):
        return QOTD()


endpoints.serverFromString(reactor, "tcp:1234").listen(EchoFactory())
reactor.run()
# #!/usr/bin/env python
#
# import socket
#
# TCP_IP = '127.0.0.1'
# TCP_PORT = 62
# BUFFER_SIZE = 20  # Normally 1024, but we want fast response
#
# s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# s.bind((TCP_IP, TCP_PORT))
# s.listen(1)
#
# conn, addr = s.accept()
# print('Connection address:', addr)
# while 1:
#     data = conn.recv(BUFFER_SIZE)
#     if not data: break
#     print("received data:", data)
#     conn.send(bytes("\n\r=",'utf-8')+data)  # echo
# conn.close()

#
# # telnet 127.0.0.1 62.
#
# # !/usr/bin/env python
#
# import socket
#
# TCP_IP = '127.0.0.1'
# TCP_PORT = 5005
# BUFFER_SIZE = 1024
# MESSAGE = "Hello, World!"
#
# s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# s.connect((TCP_IP, TCP_PORT))
# s.send(MESSAGE)
# data = s.recv(BUFFER_SIZE)
# s.close()
#
# print("received data:", data)
#
# !/usr/bin/env python

import socket
from threading import Thread
from socketserver import ThreadingMixIn


class ClientThread(Thread):
    def __init__(self, ip, port):
        Thread.__init__(self)
        self.ip = ip
        self.port = port
        print("[+] New thread started for " + ip + ":" + str(port))

    def run(self):
        while True:
            data = conn.recv(2048)
            if not data: break
            print("received data:", data)
            conn.send(data)  # echo


TCP_IP = '127.0.0.1'
TCP_PORT = 11111
BUFFER_SIZE = 20  # Normally 1024, but we want fast response

tcpsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcpsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
tcpsock.bind((TCP_IP, TCP_PORT))
threads = []

while True:
    tcpsock.listen(4)
    print("Waiting for incoming connections...")
    (conn, (ip, port)) = tcpsock.accept()
    newthread = ClientThread(ip, port)
    newthread.start()
    threads.append(newthread)

for t in threads:
    t.join()



# # protocol - application layer
#
# # !/usr/bin/env python
#
# import socket
#
# TCP_IP = '127.0.0.1'
# TCP_PORT = 64
# BUFFER_SIZE = 20  # Normally 1024, but we want fast response
#
# s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# s.bind((TCP_IP, TCP_PORT))
# s.listen(1)
#
# conn, addr = s.accept()
# print('Connection address:', addr)
# while 1:
#     data = conn.recv(BUFFER_SIZE)
#     if not data: break
#     print("received data:", data)
#     # conn.send(data)  # echo
#     if "/version" in data:
#         conn.send("Demo versionn")
#
#     if "/echo" in data:
#         data = data.replace("/echo", "")
#         conn.send(data + "n")
#
# conn.close()
#!/usr/bin/python
#
#
#
from socket import socket, AF_INET, SOCK_STREAM
s = socket(AF_INET, SOCK_STREAM)
s.bind(('127.0.0.1', 11111))
s.listen(5)
while 1:
    sock, addr = s.accept()
    while 1:
        data = sock.recv(1024) # max byte count
        print(data)
        sock.send(data.upper())
        if data == b"#":
            break
    sock.close()
    print("Connection closed")

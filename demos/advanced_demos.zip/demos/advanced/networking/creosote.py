#!/usr/bin/python
# creosote.py - first pass

import sys, socket
BUFSIZE = 128
def spew(msg, host='localhost', port=7739):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(('', 0))
    while len(msg):
        s.sendto(msg[:BUFSIZE], (host, port))
        msg = msg[BUFSIZE:]
        print("msg: ", len(msg))
    print("spew stopped")
    s.sendto(b"###", (host, port))
    s.close()

def bucket(port=7739):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(('', port))
    print('bucket waiting on port: %s' % port)
    data = b"Message: "
    while data != b"###":
        try:
            data, addr = s.recvfrom(1024)
            print(data)
        except Exception as e:
            print(e)
    print("bucket stopped")
    s.close()





# class Descriptor(object):
#     """A data descriptor that sets and returns values
#        normally and prints a message logging their access.
#     """
#
#     def __init__(self, initval=None, name='var'):
#         self.val = initval
#         self.name = name
#
#     def __get__(self, obj, objtype):
#         print('Retrieving', self.name)
#         return self.val
#
#     def __set__(self, obj, val):
#         print('Updating', self.name)
#         self.val = val
#
# class MyClass(object):
#     x = Descriptor(10, 'var "x"')
#     y = 5
#
# m = MyClass()
# print(m.x)
# m.x = 34
# print(m.x)
# m2 = MyClass()
# m2.x=9
# print(m.x)


class Descriptor(object):
    """A data descriptor that sets and returns values
       normally and prints a message logging their access.
    """

    def __init__(self, default=None, name=''):
        self.default = default
        self.name = name

    def __get__(self, obj, objtype):
        print('Retrieving {} for {}'.format(self.name, str(obj)))
        return obj.__dict__.get(self.name, self.default)

    def __set__(self, obj, val):
        print('Updating {} for {} to {}'.format(self.name, str(obj), val))
        obj.__dict__[self.name] = val

class MyClass(object):
    x = Descriptor(10, 'x')
    y = 5

m = MyClass()
print(m.x)
m.x = 34
print(m.x)
m2 = MyClass()
m2.x=9
print(m.x)
print(m2.x)
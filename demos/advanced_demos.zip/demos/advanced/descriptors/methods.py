class Foo(object):
    def __init__(self, a):
        self.a = a

    def bar(self, b):
        return self.a + b


foo = Foo(1)

bar = Foo.bar
print(bar(foo, 2))

def baz(self):
    return self.a * 2

Foo.baz = baz
print(Foo.baz(foo))
print(foo.baz())

# regular (unbound) function
print(Foo.bar)
# bound method
print(foo.bar)

print(foo.bar.__func__ is Foo.bar)
print(foo.bar.__self__ is foo)

foo2 = Foo(2)
import types # access hidden types
foo2.baz = types.MethodType(baz, foo2)

print(foo2.baz())

# simulate bound method
class BoundMethod(object):
    def __init__(self, function, instance):
        self.__func__, self.__self__ = function, instance

    def __call__(self, *args, **kwargs):
        return self.__func__(self.__self__, *args, **kwargs)

foo.baz = BoundMethod(baz, foo)
print(foo.baz())

# Descriptor: __get__ method of a function
def __get__(self, instance, owner):
    return types.MethodType(self, instance)

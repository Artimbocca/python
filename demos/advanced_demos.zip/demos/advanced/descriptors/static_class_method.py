class Dict(dict):

    def fill(klass, iterable, value=None):
        "Emulate dict_fromkeys() in Objects/dictobject.c"
        d = klass()
        for key in iterable:
            d[key] = value
        return d
    fill = classmethod(fill)

class DD(Dict):
    pass

d = DD.fill(range(5))

print(d, " - ", type(d))
from weakref import WeakKeyDictionary


class Price(object):
    def __init__(self):
        self.default = 0
        self.values = WeakKeyDictionary()

    def __get__(self, instance, owner):
        return self.values.get(instance, self.default)

    def __set__(self, instance, value):
        if value < 0 or value > 100:
            raise ValueError("Price must be between 0 and 100.")
        self.values[instance] = value
        instance.__dict__['price'] = value+2

    def __delete__(self, instance):
        del self.values[instance]


class Book(object):
    price = Price()

    def __init__(self, author, title, price):
        self.author = author
        self.title = title
        self.price = price

    def __str__(self):
        return "{0} - {1}".format(self.author, self.title)


b = Book("Joe","My life as Pete",20)
desc = Book.__dict__['price']   # vars(Book)['price']
print([str(k) for k in desc.values])

del b
print([str(k) for k in desc.values])

# print(b.price)
# print(b.__dict__['price'])





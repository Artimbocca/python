import threading

lock = threading.Lock()

print('First try :', lock.acquire())
#print('Second try:', lock.acquire())

# normal lock cannot be acquired more than once by same thread
# use lock.acquire(False) to not block
print('Second try:', lock.acquire(0))

# reentrant locks can be acquired more than once by same thread

lock = threading.RLock()

print('First try :', lock.acquire())
print('Second try:', lock.acquire(0))
import threading
import logging


class MyThread(threading.Thread):

    def run(self):
        logging.debug('running')


logging.basicConfig(
    level=logging.DEBUG,
    format='(%(threadName)-10s) %(message)s',
)

for i in range(5):
    t = MyThread()
    t.start()


class MyThreadWithArgs(threading.Thread):

    def __init__(self, group=None, target=None, name=None,
                 args=(), kwargs=None, *, daemon=None):
        super().__init__(group=group, target=target, name=name,
                         daemon=daemon)
        self.args = args
        self.kwargs = kwargs

    def run(self):
        logging.debug('running with %s and %s',
                      self.args, self.kwargs)


for i in range(5):
    t = MyThreadWithArgs(args=(i,), kwargs={'a': 'A', 'b': 'B'})
    t.start()


class Timer(threading.Thread):

    def __init__(self, interval, target,
                 args=(), kwargs={}):
        super().__init__(target=target)
        self.args = args
        self.kwargs = kwargs
        self.interval = interval
        self.target = target


    def run(self):

        logging.debug('starting {} in {} secs with {} and {}'.format(self.target.__name__,
                                                                     self.interval,
                                                                     self.args, self.kwargs))
        time.sleep(self.interval)
        if self.target:
            self.target(*self.args, **self.kwargs)

    def cancel(self):
        self.target = None


import time

def delayed():
    logging.debug('worker running')


logging.basicConfig(
    level=logging.DEBUG,
    format='(%(threadName)-10s) %(message)s',
)

t1 = Timer(0.3, delayed)
t1.setName('t1')
t2 = Timer(0.3, delayed)
t2.setName('t2')

logging.debug('starting timers')
t1.start()
t2.start()

logging.debug('waiting before canceling %s', t2.getName())
time.sleep(0.2)
logging.debug('canceling %s', t2.getName())
t2.cancel()
logging.debug('done')
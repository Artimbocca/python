import socket

def parse_links(response):
    print(response)

def fetch(url):
    sock = socket.socket()
    sock.connect(("demo.borland.com", 80))
    request = 'GET {} HTTP/1.0\r\nHost: demo.borland.com\r\n\r\n'.format(url)
    sock.send(request.encode('ascii'))
    response = b""
    chunck = sock.recv(4096)
    while chunck:
        print(chunck)
        response += chunck
        chunck = sock.recv(4096)

    links = parse_links(response)


# fetch('/Testsite/stadyn_largepagewithimages.html')


from selectors import DefaultSelector, EVENT_WRITE

selector = DefaultSelector

sock = socket.socket()
sock.setblocking(False)
try:
    sock.connect(("demo.borland.com", 80))
except BlockingIOError:
    pass

def connected():
    selector.unregister(sock.fileno())
    print('connected!')

selector.register(sock.fileno(), EVENT_WRITE, connected)

def loop():
    while True:
        events = selector.select()
        for event_key, event_mask in events:
            callback = event_key.data
            callback()
# Question:
#
# Write a program to solve a classic ancient Chinese puzzle:
# We count 35 heads and 94 legs among the chickens and rabbits in a farm. How many rabbits and how many chickens do we have?
#
# Hint:
# Use for loop to iterate all possible solutions.
#
# Solution:

def solve(numheads,numlegs):
    ns='No solutions!'
    for i in range(numheads+1):
        j=numheads-i
        if 2*i+4*j==numlegs:
            yield i,j
    return ns,ns

numheads=22
numlegs=88
solutions=[(i,j) for i, j in solve(numheads,numlegs)]
print (solutions)
import asyncio
import time

async def phase(i):
    print('in phase {}'.format(i))
    # time.sleep(0.1 * i)
    await asyncio.sleep(0.1 * i)
    print('done with phase {}'.format(i))
    return 'phase {} result'.format(i)


async def main(num_phases):
    print('starting main')
    phases = [
        phase(i)
        for i in range(num_phases)
    ]
    print('waiting for phases to complete')

    # results = await asyncio.gather(*phases)

    completed, pending = await asyncio.wait(phases, timeout=0.1)
    results = [t.result() for t in completed]
    print('results: {!r}'.format(results))

    print('{} completed and {} pending'.format(
        len(completed), len(pending),
    ))
    # Cancel remaining tasks so they do not generate errors
    # as we exit without finishing them.
    if pending:
        print('canceling tasks')
        for t in pending:
            t.cancel()
    print('exiting main')


event_loop = asyncio.get_event_loop()
try:
    event_loop.run_until_complete(main(3))
finally:
    event_loop.close()
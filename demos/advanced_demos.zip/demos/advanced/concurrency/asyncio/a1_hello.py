import asyncio

async def hello_world():
    print("Hello World!")

loop = asyncio.get_event_loop()
# Blocking call which returns when the hello_world() coroutine is done
loop.run_until_complete(hello_world())
loop.close()


def hello_world(loop):
    print('Hello World again')
    loop.stop()


# cannot simply call get_event_loop once closed
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)


# Schedule a call to hello_world()
loop.call_soon(hello_world, loop)

# Blocking call interrupted by loop.stop()
loop.run_forever()
loop.close()
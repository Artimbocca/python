import multiprocessing
import time
import sys

def daemon():
    p = multiprocessing.current_process()
    print('Starting:', p.name, p.pid)
    sys.stdout.flush()
    time.sleep(3)
    print('Exiting :', p.name, p.pid)
    sys.stdout.flush()


def non_daemon():
    p = multiprocessing.current_process()
    print('Starting:', p.name, p.pid)
    sys.stdout.flush()
    time.sleep(3)
    print('Exiting :', p.name, p.pid)
    sys.stdout.flush()


if __name__ == '__main__':
    d = multiprocessing.Process(
        name='daemon',
        target=daemon,
    )
    d.daemon = True
    print(d)

    n = multiprocessing.Process(
        name='non-daemon',
        target=non_daemon,
    )
    n.daemon = False
    print(n)
    d.start()
    print(d)
    n.start()
    print(n)
    time.sleep(1)

# wait for daemon process to exit
#    d.join()

    # d.join(2)
    # n.join()
    print("Alive? {}; {}; {}: {}".format(d.name, d.is_alive(), n.name, n.is_alive()))
    n.terminate()
    print("Alive? {}; {}; {}: {}".format(d.name, d.is_alive(), n.name, n.is_alive()))
    # d.join()
    # print("Alive? {}; {}; {}: {}".format(d.name, d.is_alive(), n.name, n.is_alive()))
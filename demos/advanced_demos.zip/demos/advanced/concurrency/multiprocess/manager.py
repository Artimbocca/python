import multiprocessing, time


def producer(ns, d, event):
    # DOES NOT UPDATE GLOBAL VALUE!
    ns.my_list.append('This is the value')
    ns.my_list = ns.my_list + ['This is concat value']
    ns.value = 9
    d['b'] = 2
    event.set()


def consumer(ns, d, event):
    try:
        val = ns.value
    except AttributeError:
        val = "not set"
    print('Before event: ns.list {}, ns.value {}, d {}'.format(ns.my_list, val, d))
    event.wait()
    print('After event: ns.list {}, ns.value {}, d {}'.format(ns.my_list, ns.value, d))



if __name__ == '__main__':
    mgr = multiprocessing.Manager()
    namespace = mgr.Namespace()
    namespace.my_list = []
    d = mgr.dict()
    d['a'] = [1]
    print(d)

    event = multiprocessing.Event()
    p = multiprocessing.Process(
        target=producer,
        args=(namespace, d, event),
    )
    c = multiprocessing.Process(
        target=consumer,
        args=(namespace, d, event),
    )

    c.start()
    # sleep a bit, otherwise the producer might actually send the event too early
    time.sleep(0.3)
    p.start()

    c.join()
    p.join()



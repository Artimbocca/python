import multiprocessing, os
import time

def worker(num):
    """thread worker function"""
    print('Worker:', num)
    time.sleep(1)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())

if __name__ == '__main__':
    jobs = []
    for i in range(3):
        p = multiprocessing.Process(target=worker, args=(i,))
        jobs.append(p)
        p.start()
        print(jobs)


    import time
    time.sleep(2)
    print(jobs)

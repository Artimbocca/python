import random
import multiprocessing
import time


def worker(s, pool):
    name = multiprocessing.current_process().name
    with s:
        pool.append(name)
        print('Work on {} started, pool {}'.format(
            name, pool))
        time.sleep(random.uniform(0.5,0.9))
        pool.remove(name)


if __name__ == '__main__':
    mgr =  multiprocessing.Manager()
    pool = mgr.list()
    s = multiprocessing.BoundedSemaphore(2)
    jobs = [
        multiprocessing.Process(
            target=worker,
            name=str(i),
            args=(s, pool),
        )
        for i in range(5)
    ]

    for j in jobs:
        time.sleep(random.uniform(0.2, 0.4))
        j.start()

    while True:
        alive = 0
        for j in jobs:
            if j.is_alive():
                alive += 1
                j.join(timeout=0.2)

        print('Jobs alive {}: '.format(alive))
        if alive == 0:
            # all done
            break
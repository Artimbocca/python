from multiprocessing import Process, Lock
from time import sleep

def f(l, i):
    if l:
        l.acquire()
        try:
            foo(i)
        finally:
            l.release()
    else:
        foo(i)


def foo(i):
    print('hello', i)
    sleep(0.1)
    print('bye', i)

if __name__ == '__main__':
    lock = Lock()

    for num in range(10):
        Process(target=f, args=(lock, num)).start()


from concurrent import futures
import time


def task(n):
    print('{}: sleeping'.format(n))
    time.sleep(0.4)
    print('{}: done'.format(n))
    return n / 10


def done(fn):
    if fn.cancelled():
        print('{}: canceled'.format(fn.arg))
    elif fn.done():
        error = fn.exception()
        if error:
            print('{}: error returned: {}'.format(
                fn.arg, error))
        else:
            result = fn.result()
            print('{}: value returned: {}'.format(
                fn.arg, result))


if __name__ == '__main__':
    with futures.ThreadPoolExecutor(max_workers=2) as ex:
        print('main: starting')
        tasks = []

        for i in range(10, 0, -1):
            print('main: submitting {}'.format(i))
            f = ex.submit(task, i)
            f.arg = i
            f.add_done_callback(done)
            tasks.append((i, f))

        time.sleep(0.6)
        for i, t in reversed(tasks[3:7]):
            if not t.cancel():
                print('main: did not cancel {}'.format(i))


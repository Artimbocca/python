from concurrent import futures
import random
import time


def task(n):
    time.sleep(random.random())
    return (n, n / 10)


ex = futures.ProcessPoolExecutor(max_workers=5)
print('starting single task')

# f = ex.submit(task, 10)
# print(f.result())   # blocks!

print('starting unordered tasks')
wait_for = [
    ex.submit(task, i)
    for i in range(5, 0, -1)
]

for f in futures.as_completed(wait_for):
    print('result: {}'.format(f.result()))
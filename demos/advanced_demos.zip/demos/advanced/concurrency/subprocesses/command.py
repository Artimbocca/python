import subprocess

completed = subprocess.run(['ls', '-1'])
print('returncode:', completed.returncode)

completed = subprocess.run('echo $HOME', shell=True)
print('returncode:', completed.returncode)

try:
    subprocess.run(['false'], check=True)
except subprocess.CalledProcessError as err:
    print('ERROR:', err)
    

completed = subprocess.run(
    ['ls', '-1'],
    stdout=subprocess.PIPE,
)
print('returncode:', completed.returncode)
print('Have {} bytes in stdout:\n{}'.format(
    len(completed.stdout),
    completed.stdout.decode('utf-8'))
)
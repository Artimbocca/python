import mymodule
mymodule.sayhi()
print ('Version', mymodule.__version__)

#Alternatively from .. import can be used :

from mymodule import sayhi, __version__
sayhi()
print('Version', __version__)

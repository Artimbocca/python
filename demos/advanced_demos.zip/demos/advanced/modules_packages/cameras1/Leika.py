def LeikaInfo():
    print ("Leika camera")
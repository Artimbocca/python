with open("foo2.py", 'r') as fd:
    fd.read()
    fd.__
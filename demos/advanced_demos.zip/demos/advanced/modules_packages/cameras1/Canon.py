from .Nikon import NikonInfo

def CanonInfo():
    print ("Canon camera")
def NikonInfo():
    print ("Nikon camera")


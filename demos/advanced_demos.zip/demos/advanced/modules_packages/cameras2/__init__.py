from cameras2.Canon import CanonInfo
from cameras2.Leika import LeikaInfo
from cameras2.Nikon import NikonInfo

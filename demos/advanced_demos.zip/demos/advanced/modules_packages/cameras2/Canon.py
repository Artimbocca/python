def CanonInfo():
    print ("Canon camera")


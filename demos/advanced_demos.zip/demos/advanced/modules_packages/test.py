def print_func(s):
    print("Hello: {}".format(s))
import cameras2

cameras2.NikonInfo()
cameras2.CanonInfo()
cameras2.LeikaInfo()

#from cameras2 import NikonInfo, CanonInfo, LeikaInfo 
#
#NikonInfo()
#CanonInfo()
#LeikaInfo()

import sys
print(sys.path)
import cameras1.Nikon
import cameras1.Canon
import cameras1.Leika
from cameras1 import Leika
cameras1.Nikon.NikonInfo()
cameras1.Canon.CanonInfo()
Leika.LeikaInfo()
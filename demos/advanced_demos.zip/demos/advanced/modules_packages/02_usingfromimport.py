from math import sqrt

for i in range(1000,1005):
    r = sqrt(i)
    print("square root of {} = {:9.3f}".format(i, r))

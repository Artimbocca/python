import logging
import module05
import module06

logger = logging.getLogger(__name__)

def main():
    logging.basicConfig(filename='moduleloggers.log', filemode='w', level=logging.WARNING)
    logger.debug('debug main')
    logger.info('info main')
    logger.warning('warning main')
    logger.error('error main')
    logger.critical('critical main')
    module05.a()
    module06.b()

if __name__ == '__main__':
    main()
import logging

logger = logging.getLogger(__name__)

def y():
    logger.setLevel(logging.DEBUG)
    logger.debug('debug : Inside y from module04')
    logger.info('info : Inside y from module04')
    logger.warning('warning : Inside y from module04')
    logger.error('error : Inside y from module04')
    logger.critical('critical : Inside y from module04')
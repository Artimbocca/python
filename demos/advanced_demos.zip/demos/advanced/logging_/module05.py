import logging

logger = logging.getLogger(__name__)
file = logging.FileHandler('module05.log')

def a():
    logger.setLevel(logging.CRITICAL)
    logger.addHandler(file)
    logger.debug('debug : Inside a from module05')
    logger.info('info : Inside a from module05')
    logger.warning('warning : Inside a from module05')
    logger.error('error : Inside a from module05')
    logger.critical('critical : Inside a from module05')
import logging

logger = logging.getLogger(__name__)
file = logging.FileHandler('module06.log')

def b():
    logger.setLevel(logging.DEBUG)
    logger.addHandler(file)
    logger.debug('debug : Inside b from module06')
    logger.info('info : Inside b from module06')
    logger.warning('warning : Inside b from module06')
    logger.error('error : Inside b from module06')
    logger.critical('critical : Inside b from module06')
import logging

def f():
    logging.info('Inside f from module01')
import logging
import module01
import module02

def main():
    logging.basicConfig(level=logging.INFO)
    #logging.basicConfig(filename='application.log', level=logging.INFO)
    logging.info('Started')
    module01.f()
    module02.g()
    logging.info('Finished')

if __name__ == '__main__':
    main()
import logging

def g():
    logging.info('Inside g from module02')
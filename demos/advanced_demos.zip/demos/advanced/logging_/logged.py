import advanced.logging_.exception_log as el
import logging



@el.exception2(el.create_logger())
def zero_divide():
    1 / 0

# logging.basicConfig(level=logging.DEBUG)

if __name__ == '__main__':
    print(logging.getLogger().handlers)
    # logging.info("Starting")
    print(logging.getLogger().handlers)
    zero_divide()
import logging

logger = logging.getLogger(__name__)

def x():
    logger.setLevel(logging.CRITICAL)
    logger.debug('debug : Inside x from module03')
    logger.info('info : Inside x from module034')
    logger.warning('warning : Inside x from module03')
    logger.error('error : Inside x from module03')
    logger.critical('critical : Inside x from module03')
import logging
import module03
import module04

logger = logging.getLogger(__name__)

def main():
    logging.basicConfig(filemode='w', level=logging.WARNING)
    logger.debug('debug main')
    logger.info('info main')
    logger.warning('warning main')
    logger.error('error main')
    logger.critical('critical main')
    module03.x()
    module04.y()

if __name__ == '__main__':
    main()
import logging
logging.warning('Watch out!')  # prints message to console
logging.info('I told you so')  # prints nothing

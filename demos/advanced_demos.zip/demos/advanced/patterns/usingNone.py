a = None
print("is: {}, ==: {}".format(a is None, a == None))

print(id(None))
print(type(None))
type(None)

class Strange:
    def __eq__(self, other):
        return True

funny = Strange()
print("is None: {}, == None: {}".format(funny is None, funny == None))
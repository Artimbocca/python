from adapter import Dog, Person
import random

class Cat(object):
    def __init__(self, name):
        self.name = name
    def meow(self):
        return "meow"

class CreatureAdapter(object):
    """Adapts a creature for clients in 2D Land"""

    def __init__(self, creature, make_noise):
        """Pass in the function to use as 'make_noise'"""
        self.creature = creature
        self.make_noise = make_noise

    def __getattr__(self, attr):
        """Everything else is delegated to the object"""
        return getattr(self.creature, attr)


class AdapterLookupError(KeyError):
    pass


class CreatureFactory:
    def __init__(self, methodtable):
        self._table = methodtable

    def make(self, cls, name):
        if cls not in self._table:
            raise AdapterLookupError
        obj = cls(name)
        def method():
            return self._table[cls](obj)
        return CreatureAdapter(obj, method)

    def random(self, n=1):
        return [(lambda i, cls: self.make(cls, cls.__name__ + str(i))) (i, random.choice(list(self._table.keys()))) for i in range(n)]


if __name__ == '__main__':

    factory = CreatureFactory({Cat:Cat.meow, Dog:Dog.bark, Person:Person.make_noise})
    a = factory.make(Cat,'cat')
    creatures = factory.random(10)
    for c in creatures:
        print(c.make_noise())


# alternative: make proxy more general using __getattr__
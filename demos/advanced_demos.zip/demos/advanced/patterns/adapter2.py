def completed(source):
    print(source, "completed")

def countdown(num, callback):
    for i in range(num, 0, -1):
        print("{} …".format(i))
    callback()

def main():
    def nullarg_callback():
        completed("countdown")
    countdown(3, nullarg_callback)

if __name__ == "__main__":
    main()
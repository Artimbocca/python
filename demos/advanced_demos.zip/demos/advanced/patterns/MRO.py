class A:
    def foo(self): print("A")

class B:
    def foo(self): print("B")

class C (A, B):
    pass

class D (B, A):
    pass

# class E (C, D):
#     pass

# class F (A, D):
class F (D, A):
    pass

A().foo()
B().foo()
C().foo()
print(C.__mro__)
D().foo()
print(D.__mro__)
# E()  # TypeError: no consistent method resolution order found
print(F.__mro__)
import logging
logging.basicConfig(level=logging.INFO,format="%(levelname)s: %(message)s")
class LoggingDict(dict):
    def __setitem__(self, key, value):
        logging.info('Setting %r to %r in LoggingDict %s' % (key, value, id(self)))
        # super().__setitem__(key, value)
        dict.__setitem__(self, key, value)


d = LoggingDict()
d[1] = 'one'

# super is indirect reference, computed at runtime, so we can make it point elsewhere

import collections
class LoggingOD(LoggingDict, collections.OrderedDict):
    pass

from pprint import pprint
pprint (LoggingOD.__mro__)

#use keyword dictionary to be flexible in signature
class Shape:
    def __init__(self, shapename, **kwds):
        self.shapename = shapename
        super().__init__(**kwds)

class ColoredShape(Shape):
    def __init__(self, color, **kwds):
        self.color = color
        super().__init__(**kwds)

cs = ColoredShape(color='red', shapename='circle')

# make sure method always exists
class Root:
    def draw(self):
        # the delegation chain stops here
        assert not hasattr(super(), 'draw')

class Shape(Root):
    def __init__(self, shapename, **kwds):
        self.shapename = shapename
        super().__init__(**kwds)
    def draw(self):
        print('Drawing.  Setting shape to:', self.shapename)
        super().draw()

class ColoredShape(Shape):
    def __init__(self, color, **kwds):
        self.color = color
        super().__init__(**kwds)
    def draw(self):
        print('Drawing.  Setting color to:', self.color)
        super().draw()

cs = ColoredShape(color='blue', shapename='square')
cs.draw()

class Moveable:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def draw(self):
        print('Drawing at position:', self.x, self.y)

class MovableColoredShape(ColoredShape, Moveable):
    pass

MovableColoredShape(color='red', shapename='triangle',
                    x=10, y=20).draw()

class MoveableAdapter(Root):
    def __init__(self, x, y, **kwds):
        self.movable = Moveable(x, y)
        super().__init__(**kwds)
    def draw(self):
        self.movable.draw()
        super().draw()

class MovableColoredShape(ColoredShape, MoveableAdapter):
    pass

MovableColoredShape(color='red', shapename='triangle',
                    x=10, y=20).draw()
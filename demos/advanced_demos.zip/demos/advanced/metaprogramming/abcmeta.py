from abc import ABCMeta

class MyABC(metaclass=ABCMeta):
    pass

MyABC.register(tuple)

assert issubclass(tuple, MyABC)
assert isinstance((), MyABC)


from abc import ABC, abstractmethod

class MyABC(ABC):

    @abstractmethod
    def foo(self):
        raise NotImplementedError

MyABC.register(tuple)

assert issubclass(tuple, MyABC)
assert isinstance((), MyABC)

# a = MyABC()
# a.foo()


class Foo:
    def __getitem__(self, index):
        return self
    def __len__(self):
        return 0
    def get_iterator(self):
        return iter(self)

class MyIterable(metaclass=ABCMeta):
    @abstractmethod
    def __iter__(self):
        while False:
            yield None
    def get_iterator(self):
        return self.__iter__()
    @classmethod
    def __subclasshook__(cls, C):
        if cls is MyIterable:
            if any("__iter__" in B.__dict__ for B in C.__mro__):
                return True
        return NotImplemented

MyIterable.register(Foo)
print(MyABC._abc_registry.data)


class Singleton(type):
    instance = None

    def __call__(cls,*args,**kw):
        if not cls.instance:
            cls.instance = super(Singleton,cls).__call__(*args, **kw)
            #cls.instance = super().__call__(*args, **kw)
            #cls.instance = type.__call__(cls,*args, **kw)
        return cls.instance


class ASingleton(metaclass=Singleton):
    pass


class AnotherSingleton(metaclass=Singleton):
    pass


a = ASingleton()
b = ASingleton()
print(a is b)
print(id(a), id(b))

a = AnotherSingleton()
b = AnotherSingleton()
print(a is b)
print(id(a), id(b))
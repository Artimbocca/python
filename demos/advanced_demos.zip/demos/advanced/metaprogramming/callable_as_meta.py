# a class object is made by metaclass.__call__()

class Foo(metaclass=print):
    pass

print(Foo)


# https://blog.ionelmc.ro/2015/02/09/understanding-python-metaclasses/#slots
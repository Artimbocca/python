class Foo:
    pass


def set_name(x, name):
    x.name = name


def get_name(x):
    return x.name


def show(x):
    if not getattr(x,'fullname', ''):
        x.fullname = "{}: {}".format(x.__class__.__name__,x.name)
    print(x.fullname)


Foo.__init__ = set_name
Foo.show = show
f = Foo("Ko")
f.show()


class Baz:
    def __str__(self):
        return getattr(self,'fullname', self.name)


def makeWithMixin(cls, mixin):
    class NewClass(cls, mixin): pass

    # rename class
    NewClass.__name__ = "%s_%s" % (cls.__name__, mixin.__name__)
    return NewClass


m = makeWithMixin(Foo, Baz)("KK")
print(m)
m.show()
print(m)

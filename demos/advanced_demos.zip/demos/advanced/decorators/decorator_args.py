def hello(greeting="Hello ...."):

    def make_wrapper(original_function):
        def wrapper(*args, **kwargs):
            original_function(*args, **kwargs)
            print(greeting)
        return wrapper
    return make_wrapper


@hello(greeting="Hello Galaxy")
@hello(greeting="Hello SolarSystem")
def welcome(planet=None):
    if planet:
        print("Hello "+planet)
    else:
        print("Hello World")

@hello(greeting="Bye Galaxy")
@hello(greeting="Bye SolarSystem")
def goodbye(*args):
    print('Bye', *args)

welcome("Earth")
goodbye("planets", "moons", "species")

@hello()
def test(a):
    print(a)

test("kk")



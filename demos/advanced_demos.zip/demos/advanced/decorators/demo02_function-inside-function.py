def greet(name):
    def greeting():
        return "Hello "

    result = greeting()+name
    return result

print (greet("Albert"))

# Outputs: Hello Albert
from functools import wraps, partial
def logged(func):
    @wraps(func)
    def with_logging(*args, **kwargs):
        print(func.__name__ + " was called")
        return func(*args, **kwargs)
    return with_logging

@logged
def f(x):
   """does some math"""
   return x + x * x
print(f(2))
print(f.__name__)  # prints 'f'
print(f.__doc__)   # prints 'does some math'


def foo(a, b, c):
    print(a, b, c)


foo2 = partial(foo, 4, 5)

for i in range(9):
    foo2(i)

# def debug(prefix="INFO"):
#     def real_decorator(func):
#         def wrapper(*args, **kwargs):
#             print(prefix, func.__name__)
#             func(*args, **kwargs)
#         return wrapper
#     return real_decorator
#

# def debug(func=None, prefix="INFO"):
#     def real_decorator(func):
#         def wrapper(*args, **kwargs):
#             print(prefix, func.__name__)
#             func(*args,**kwargs)
#         return wrapper
# 
#     if callable(func):
#         return real_decorator(func)
#     else:
#         # def debugp(func):
#         #     return debug(prefix, func.__name__)
#         # return debugp
#         return partial(debug, prefix=prefix)
# 


def debug(func=None, *, prefix='INFO'):
    if func is None:
        return partial(debug, prefix=prefix)
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(prefix, func.__name__)
        return func(*args, **kwargs)
    return wrapper

@debug (prefix="WARN")
def baz(a, b, c):
    print(a, b, c)


baz(999,88, 8)
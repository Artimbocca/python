def greet(name):
    return "Hello " + name


def call(func):
    other_name = "Albert"
    return func(other_name)  


print (call(greet))

# Outputs: Hello Albert
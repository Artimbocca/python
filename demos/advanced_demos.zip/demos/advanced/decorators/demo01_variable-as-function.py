def greet(name):
    return "hello " + name

greet_someone = greet
print (greet_someone("Albert"))

# Outputs: hello Albert
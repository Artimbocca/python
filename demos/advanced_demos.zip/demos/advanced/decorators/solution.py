# def memoize(f):
#     memo = {}
#
#     def helper(x):
#        memo = {} if x not in memo:
#             memo[x] = f(x)
#             print('cached {}: {}'.format(x,memo[x]))
#         else:
#             print('reused')
#         return memo[x]
#
#     return helper


def memoize(f):
    memo = {}

    def helper(*args):
        x = (f,args)
        if x not in memo:
            memo[x] = f(*args)
            print('cached {}: {}'.format(x,memo[x]))
        else:
            print('reused ', memo[x])
        return memo[x]

    return helper


def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n - 1) + fib(n - 2)


fib = memoize(fib)

print(fib(34))


def count(f):
    counter = {}

    def helper(*args):
        x = (id(f),args)
        if x not in counter:
            counter[x] = 0
            print('added {}'.format(x))
        else:
            print('{}: {}')
        return counter[x]

    return helper

print([list(r) for  r in [range(0,5), range(5,10), range(10,15)]])

d = {1:2, 3:4}
vals = d.values()
d[4] = 5
print(vals)
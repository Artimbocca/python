# registry  =  {}
#
# def register(cls):
#     registry[cls.__clsid__] = cls
#     return cls#
# @register
# class Foo(object):
#     __clsid__ = "123-456"
#
# @register
# class Bar(object):    # if type(registry) is type:
    #     cls = registry
    #     registry = 'default'
    #     return decorate(cls)
    # else:
#     __clsid__ = "ABC-EFG"
#
# print (registry)

#
# @register
# class Foo(object):
#     __clsid__ = "123-456"
#
# @register
# class Bar(object):
#     __clsid__ = "ABC-EFG"
#
# print (registry)


registries = {'default': {}}


def register(registry='default'):
    # _registry = registries.get(registry, {})
    # registries[_registry] =  _registry

    def decorate(cls):

        try:
            _registry = registries[registry]
        except KeyError:
            _registry = registries[registry] = {}
        _registry[cls.__clsid__] = cls
        return cls

    if type(registry) is type:
        cls = registry
        registry = 'default'
        return decorate(cls)
    else:
        return decorate


@register(registry='test')
class Foo(object):
    __clsid__ = "123-456"


@register
class Bar(object):
    __clsid__ = "ABC-EFG"


@register()
def foo():
    pass

print(registries)
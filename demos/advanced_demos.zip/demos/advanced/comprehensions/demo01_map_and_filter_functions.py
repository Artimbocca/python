def square(x):
    return x*x


def even(x):
    return 0 == x % 2



some_list = list(map(square, range(10,20)))
print (some_list)

some_list = list(filter(even, range(10,20)))
print (some_list)

some_list = list(map(square, filter(even, range(10,20))))
print (some_list)


some_list = list(map(lambda x,y: x*y, range(3), filter(even, range(10,20))))
print (some_list)

# sequence can be of anything, also of functions
def square(x):
    return x**2


def cube(x):
    return x**3


funcs = [square, cube]
for r in range(5):
    value = map(lambda x: x(r), funcs)
    print(value)
    # print(list(value))

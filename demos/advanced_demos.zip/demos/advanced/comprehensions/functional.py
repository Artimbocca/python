# Normal statement-based flow control
# if < cond1 >:   func1()
# elif < cond2 >: func2()
# else:
#     func3()
#
# # Equivalent "short circuit" expression
# ( < cond1 > and func1()) or ( < cond2 > and func2()) or (func3())

def name(n):
    if n == 1:
        return 'one'
    elif name == 2:
        return 'two'
    else:
        return 'other'

fname = lambda x : (x==1 and 'one') or (x==2 and 'two') or 'other'

print(name(1), fname(1))


s = [1,4,5,10]

print (sum(s))
print (min(s))
print (max(s))

l = list(s)
print (l)
t = tuple(s)
print (t)
st = set(s)
print (st)


def coroutine(n):
    try:
        while True:
            x = (yield)
            print(n+x)
    except GeneratorExit:
        pass
targets = [
 coroutine(10),
 coroutine(20),
 coroutine(30),
]
for target in targets:
    next(target)
for i in range(5):
    for target in targets:
        target.send(i)
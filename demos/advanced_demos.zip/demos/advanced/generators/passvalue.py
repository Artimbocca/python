def counter(maximum):
    i = 0
    while i < maximum:
        val = (yield i)
        # If value provided, change counter
        if val is not None:
            i = val
        else:
            i += 1


it = counter(10)

for i in it:
    print(i)
    if i == 4:
        print(it.send(7))
        #print("at send: {}".format(it.send(7)))


# while True:
#     print(it.send(None))


def gen():
    n = 0
    n = yield 4 + n
    print(n)
    n = yield 5 + n
    print(n)
    n = yield 7
    print(n)
    return n

def gen2():
    t = yield from gen()
    print(t)
    return t
# g = gen()
# next(g)
# next(g)
# next(g)

for x in gen2():
    print(x)

def foo():
    g = gen2()
    # for i in g:
    #     print("foo ", i)

    t = g.send(None)
    t += g.send(t)
    t += g.send(t)
    t += g.send(t)
    return t

# foo()

# it = counter(10)
# i = 0
# while True:
#     try:
#         i = it.send(3 if i == 1 else None)
#         print(i)
#     except StopIteration:
#         break



# def counter2(maximum, f=lambda x:x):
#     i = 0
#     while i < maximum:
#         val = (yield f(i))
#         # If value provided, change counter
#         if callable(val):
#             f = val
#         else:
#             i += 1
#

# it = counter2(10)
#
# for i in it:
#     print(i)
#     if i == 4:
#         print(it.send(lambda x: x*2))

# it = counter2(10)

# for n in it:
#     #print("n ", n)
#     print(it.send(lambda x: x+n))
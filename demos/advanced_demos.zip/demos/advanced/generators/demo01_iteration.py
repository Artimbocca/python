for x in [1,4,5,10]:
    print (x)   # 1 4 5 10

prices = { 'GOOGLE' : 490.10, 'IBM' : 145.23, 'YAHOO' : 21.71 }
for key in prices:
    print (key) # GOOGLE IBM YAHOO

s = "Mars!"
for c in s:
    print (c)  # M a r s !

for line in open("realprogrammers.txt"):
    print (line)
def gen_fn():
  result = yield 1
  print('result of yield: ' + result) # 'joe'
  result2 = yield 2
  print('result of 2nd yield: ' + result2) # 'bob'
  return 'we are done'

def caller_fn():
  gen = gen_fn()
  rv = yield from gen
  print('return value of yield-from: ' + rv) # 'we are done'
  return 'caller_fn is done!'

caller = caller_fn()
x = caller.send(None)
print(x) # should be 1
y = caller.send('joe')
print(y) # should be 2
try:
  caller.send('bob')
except StopIteration as e:
  print(e) # 'caller_fn is done!'
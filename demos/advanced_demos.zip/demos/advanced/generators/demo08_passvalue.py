def counter(maximum):
    i = 0
    while i < maximum:
        val = (yield i)
        # If value provided, change counter
        if val is not None:
            i = val
        else:
            i += 1

it = counter(10)

# for i in it:
#     print(i)
#     if i == 4:
#         print(it.send(-5))

# for i in it:
#     print(i)
#     if i == 4:
#         print(it.send(7))
#
def skippy(n, skipat, skipto):
    it = counter(n)
    for i in it:
        yield i
        if i == skipat:
            it.send(skipto)

print([x for x in skippy(20,4,12)])
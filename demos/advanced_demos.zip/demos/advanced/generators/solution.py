#1 Infinite number generator
def count(start=0):
    while True:
        yield start
        start +=1

# utility to check endless generators like this one
def check(gen):
    s = ""
    while not s:
        print(next(gen), end=" ")
        s = input()

#2 First n numbers
def firstn(gen, n):
    for i in range(n):
        yield next(gen)


def prime(primes, n):
    for i in primes:
        if not n % i:
            return False
    return True


def sieve2(n=10):
    ints = firstn(count(2), n)
    yield 2
    primes = [2]
    for i in ints:
        if prime(primes, i):
            yield i
            primes.append(i)


#3 fibonacci generator

def fibgen():
    a, b = 0, 1
    while True:
        yield b
        a, b = b, a+b

# recursive versions, will run into problems (Python generally accepts depth of 1000)
def fib(n):
    return n if n in [0, 1] else fib(n - 1) + fib(n - 2)

def fib2(n, sum=0):
    if n < 1:
        return sum
    else:
        return fib2(n-1, sum+n)

#4 primes using generator, not yet a sieve!
def prime(primes, n):
    for i in primes:
        if not n % i:
            return False
    return True


def primer(n=10):
    ints = firstn(count(2), n)
    yield 2
    primes = [2]
    for i in ints:
        if prime(primes, i):
            yield i
            primes.append(i)


if __name__ == '__main__':

    #fib2(999)
    # for fn in fibgen():
    #     print(fn)
    # print([f for f in fibgen(200)])

    for i in primer():
        print(i)




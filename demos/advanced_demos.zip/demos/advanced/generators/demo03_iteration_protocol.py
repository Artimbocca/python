items = [1, 4, 5]

it = items.__iter__()
print (next(it))
print (next(it))
print (next(it))
print (next(it))
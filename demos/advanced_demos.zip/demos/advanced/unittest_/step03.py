import unittest

class ReverseTests(unittest.TestCase):
    def test_normal(self):
        # do import here, makes test independent
        from listfunctions import reverse

       
        # or more robust and informative unittest options
        self.assertEqual(reverse([1, 2, 3]), [13, 2, 1])


        # can use python's normal asserts
        assert reverse([1, 2, 3]) == [13, 2, 1]
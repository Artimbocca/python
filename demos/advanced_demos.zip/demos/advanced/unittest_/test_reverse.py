from unittest import TestCase
from listfunctions import reverse

class TestReverse(TestCase):
    def test_reverse(self):
        self.fail()

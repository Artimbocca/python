def reverse(aList):
    aList.reverse()
    return aList
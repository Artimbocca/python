i = 5
# print ('Value is', i); # Error! Notice a single space at the start of the line
print ('I repeat, the value is', i)
print ('hello python', end='')
print (' on the same line as previous print output')


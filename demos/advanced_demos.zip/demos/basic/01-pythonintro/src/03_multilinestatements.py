item_one = 1
item_two = 2
item_three = 3

total = item_one + \
        item_two + \
        item_three
        
print (total)


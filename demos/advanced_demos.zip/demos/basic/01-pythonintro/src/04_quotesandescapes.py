
print ('hello' + " " + '''world''')
print ('That \'s a brave new world')
print ('a')
print ('b')
import os
os.mkdir("test1")
os.mkdir("test2")
os.rmdir( "test1")

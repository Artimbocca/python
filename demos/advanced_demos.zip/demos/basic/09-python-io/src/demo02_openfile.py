var = open ("test.txt", "rt")
print (var)

var = open ("test.txt", "rb")
print (var)

var = open ("test.txt", "rb", buffering = 0)
print (var)

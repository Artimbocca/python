s = input("Enter some input : ")
print (s)
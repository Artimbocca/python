str1 = 'Hello World!'

print (str1)           # Prints complete string
print (str1[0])        # Prints first character of the string
print (str1[2:5])      # Prints characters starting from 3rd to 6th
print (str1 * 2)       # Prints string two times
print (str1 + "TEST")  # Prints concatenated string

var1 = 'Hello World!'
var2 = "Python Programming"
print ("var1[0]: ", var1[0])
print ("var2[1:5]: ", var2[1:5])

#var1[0] = 'a'  # error

print ("Updated String :- ", var1[:6] + 'Python')

print ("String with \t\t\t escape characters")
print (r"Raw String with \t\t\t escape characters")
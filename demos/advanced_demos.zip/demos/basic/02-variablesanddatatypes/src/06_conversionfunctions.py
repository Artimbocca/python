i = 65
print (chr(i))
print (hex(i))

i = 273
print (type(i))

b = str(i)
print (b)
print (type(b))

x = 111

y1 = eval('x+3')
print (y1)

y2 = repr(x)
print (y2)

y3 = str(x)
print (y3)
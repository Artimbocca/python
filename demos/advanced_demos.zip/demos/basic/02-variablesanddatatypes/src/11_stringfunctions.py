print ("they're bill's friends from the UK".title()) #"They'Re Bill'S Friends From The Uk"

print ('   spacious   '.rstrip())         # '   spacious'

print ('mississippi'.rstrip('ip'))        # 'mississ'

print ('   spacious   '.strip())          # 'spacious'

print ('www.example.com'.lstrip('cmowz.')) # 'example.com'
# all characters belonging to cmowz are removed from the left 
# until non matching character is met

print ('www.example.com'.rstrip('cmowz.')) # 'www.example'
# all characters belonging to cmowz are removed from the right 
# until non matching character is met

print ('Py' in 'Python')                  # True 



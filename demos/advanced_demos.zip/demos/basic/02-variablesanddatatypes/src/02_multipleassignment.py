a = b = c = 10
print (a, b, c)

a = 11;
print (a, b, c)

a, b, c = 1, 2, "pipo"
print (a, b, c)
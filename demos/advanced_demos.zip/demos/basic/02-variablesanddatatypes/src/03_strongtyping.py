a = 'Day'
b = 1
#c = a + b # gives an error
c = a + str(b)
print (c)
i = 10
print (i)

j = float(i)
print (j)

j = 3.33
i = int(j)
print (i)

i = int("255",10)
print (i)

i = int("255",8)
print (i)

i = bool(3)
print (i)

i = bool(0)
print (i)
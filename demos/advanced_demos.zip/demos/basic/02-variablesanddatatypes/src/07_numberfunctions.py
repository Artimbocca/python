from math import ceil, floor, sqrt, fabs

print (ceil(3.1))

print (floor(3.1))

print (max (1, 2, 5, 3))

print (min (1, 2, 5, 3))

print (pow(2,2))

print (sqrt(16))

print (abs(-11))

print (fabs(-11))
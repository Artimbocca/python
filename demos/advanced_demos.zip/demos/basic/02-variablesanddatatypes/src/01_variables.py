var1 = 10
var2 = 20
print (var1, var2)
var3 = var1 + var2
print (var3)

var1 = 'somestring'
var2 = 'otherstring'
print (var1, var2)
var3 = var1 + var2
print (var3)
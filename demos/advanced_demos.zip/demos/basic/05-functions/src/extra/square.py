# A function definition:
def square(x):
    'Calculates the square of the number x.'
    return x*x

print (square(3))
print (square(5))
def printinfo( title, name, age, sex, country ):
    "This prints name and age passed into this function"
    print ("Title: ", title)
    print ("Name: ", name)
    print ("Age: ", age)
    print ("Sex: ", sex)
    print ("Country: ", country)
    return

printinfo( country='NL', sex='female', title='Miss', age=25, name="Gloria") 
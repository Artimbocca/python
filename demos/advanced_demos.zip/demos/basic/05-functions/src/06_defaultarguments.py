def testDefaultArgs(arg1='default1', arg2='default2'):
    """A function with default arguments.
    """
    print ('arg1:', arg1)
    print ('arg2:', arg2)

testDefaultArgs()
# Filename: simplestclass.py
 
class Person:
    'Simple Person class'
    pass # An empty block
 
p1 = Person()
print(Person.__doc__)
print(p1)

p2 = Person()
print(Person.__doc__)
print(p2)

a = [1, 2, 3, 4, 5]
b = [100, 200, 300, 400, 500]

for idx, value in enumerate(a):
        b[idx] += value

print b



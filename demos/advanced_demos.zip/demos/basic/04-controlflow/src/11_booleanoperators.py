print (True and False) # False

print (True or False)  # True

print (not True)       # False

print (not False)      # True

print (True is True)   # True

print (True is False)  # False

print ('a' is 'a')     # True

print (False and 'a' or 'b') # 'b'

print (True and 'a' or 'b')  # 'a'

if (3):
    print ("3 is " + str(True))
if (-3):
    print ("-3 is " + str(True))
if (0):
    print ("0 is " + str(True))
else :
    print ("0 is " + str(False))
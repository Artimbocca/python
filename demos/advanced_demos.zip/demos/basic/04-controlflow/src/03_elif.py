num = input('Enter a number: ')
if int(num) > 0:
    print ('The number is positive')
elif int(num) < 0:
    print ('The number is negative')
else:
    print ('The number is zero')

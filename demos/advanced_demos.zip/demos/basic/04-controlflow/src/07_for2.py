rrange = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
for number in rrange:
    print (number)

for number in range(12,17,2):
    print (number)

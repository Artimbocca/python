name = input('What is your name? ')
if name.endswith('Gumby'):
    print ('Hello, Mr. Gumby')
else:
    print ('Hello, stranger')

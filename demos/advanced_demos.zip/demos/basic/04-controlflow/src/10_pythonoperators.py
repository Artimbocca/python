i = 10
j = 11

print (j/i)
print (j//i)

print (i>j)      # False

print (i != j)   # True

s = "ABC"
print ('B' in s) # True

a = 1
b = 2
print (a & b)    # 0

j = i
print (i is j)

j = j + 1
print (i is j)
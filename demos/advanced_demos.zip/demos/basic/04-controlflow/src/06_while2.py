name = ''
while not name:
    name = input('Please enter your name: ')
print ('Hello, %s!' % name)

while True:
    name = input('What is your name? ')
    if len(name) > 0:
        print ('Hello, ' + name)
    else:
        break

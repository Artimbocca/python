words = ['this', 'is', 'an', 'ex', 'parrot']
for word in words:
    print (word)

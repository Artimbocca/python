Money = 2000

def AddMoney():
    # Uncomment the following line to fix the code:
    Money = 0
    global Money
    Money = Money + 1

print (Money)
AddMoney()
print (Money)


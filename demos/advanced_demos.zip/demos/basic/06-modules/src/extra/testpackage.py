#from package_example import *
#
#print dir()
#
#c1 = class1()
#c2 = class2()
#c1.show()
#c2.show()




import cameras1.Canon
import cameras1.Leika
import cameras1.Nikon

cameras1.Nikon.NikonInfo()
cameras1.Canon.CanonInfo()
cameras1.Leika.LeikaInfo()
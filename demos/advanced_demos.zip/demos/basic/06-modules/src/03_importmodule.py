import testmodules
testmodules.test("aaa", 11)

from testmodules import *
test("BBB", 11)

p = Person('a', 'b')
print (p)